<template>
  <div id="app">
    <router-view></router-view>
  </div>
</template>

<script>
export default {
  name: 'App',
  data(){
    return{
    }
  },
  mounted() {
    // var Us = localStorage.getItem('user')
    // this.GLOBAL.userData = JSON.parse(Us)

  },
  destroyed(){

  },
  methods:{


  },


}
</script>

<style>


</style>

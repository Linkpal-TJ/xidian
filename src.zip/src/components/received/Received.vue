<template>
    <div class="received">
      <div  class="index">
        <div ref="left" class="left">
          <div class="logo" v-if="!this.GLOBAL.isState"><img src="../../assets/imgs/logo.png" alt=""></div>


          <!--<el-menu :collapse-transition="false" :router="true"  class="el-menu-vertical-demo" mode="vertical" :collapse="!isCollapse">-->
          <el-menu active-text-color="#FFD04B" background-color="#303030" text-color="#fff" :default-active="$route.path"  @select="jihuo" :collapse-transition="false" :router="true"  class="el-menu-vertical-demo" mode="vertical" :collapse="this.GLOBAL.isState">
                <el-menu-item index="/index/received" @click.native="tests">
                    <i class="el-icon-edit"></i>
                    <span slot="title">收货</span>
                </el-menu-item>
                <el-menu-item index="/index/checkout">
                  <i class="el-icon-s-check"></i>
                  <span slot="title">检验</span>
                </el-menu-item>
                <el-menu-item index="/index/enter">
                  <i class="el-icon-s-claim"></i>
                  <span slot="title">入库</span>
                </el-menu-item>
          </el-menu>





        </div>
        <div class="right" ref="right">
          <div class="right-top">
            <div class="user">
                <el-dropdown @command="handleCommand" ref="dropdown">
                  <span class="el-dropdown-link">
                    用户：{{this.GLOBAL.userData.UserName}}<i class="el-icon-arrow-down el-icon--right"></i>
                  </span>
                  <el-dropdown-menu slot="dropdown">
                    <el-dropdown-item command="loginout">退出登录</el-dropdown-item>
                  </el-dropdown-menu>
                </el-dropdown>
            </div>

            <h2>宝鸡电气移动业务平台</h2>
            <!--侧边栏按钮开始-->
            <el-radio-group v-model="isCollapse" @change="qie" style="position: absolute;margin-left:-20px;z-index: 88;">
              <el-radio-button :label="!isOpen" class="but-qie" v-if="!this.GLOBAL.isState"><i class="el-icon-d-arrow-left"></i></el-radio-button>
              <el-radio-button :label="!isOpen" class="but-qie" v-if="this.GLOBAL.isState"><i class="el-icon-d-arrow-right"></i></el-radio-button>
            </el-radio-group>
            <!--侧边栏按钮结束-->
          </div>
          <div class="right-main">
<!--            <h3 v-if="isShow">收货清单</h3>-->
            <h3 v-if="!isShow">扫码收货</h3>

            <div class="title" v-if="isShow">
              <h3 style="float:left;margin-left: 20px;">收货清单</h3>
              <div class="pi-button">
                <el-button @click="pisock" type="primary" size="medium" >选库位</el-button>
                <el-button @click="piCheck" type="primary" size="medium" >批量送检</el-button>
                <el-button @click="piEnter" type="primary" size="medium" >批量入库</el-button>
              </div>
            </div>


            <div class="received-main">
              <el-table
                ref="multipleTable"
                v-loading="loading"
                v-if="isShow"
                :data="tableData"
                @selection-change="handleSelectionChange"
                stripe
                style="width: 100%">
                <el-table-column
                  type="selection"
                  width="55">
                </el-table-column>
                <af-table-column
                  prop="FSEQ"
                  label="序号">
                </af-table-column>

                <af-table-column
                  prop="FMANAME"
                  label="物料名称">
                </af-table-column>

                <af-table-column
                  prop="FDELIVERYQTY"
                  label="送货数">
                </af-table-column>
                <af-table-column
                  prop="FRECEIVEQTY"
                  label="收货数">
                </af-table-column>
                <af-table-column
                  prop="FTOTALRECEIVEQTY"
                  label="累计收货数">
                </af-table-column>
                <af-table-column
                  prop="FSTOCK"
                  label="仓库">
                </af-table-column>
                <af-table-column
                  prop="FORDERQTY"
                  label="订单数">
                </af-table-column>
<!--                <af-table-column-->
<!--                  prop="FISCHECK"-->
<!--                  label="是否检验">-->
<!--                </af-table-column>-->
                <af-table-column
                  prop="FSTATUS"
                  label="当前状态">
                  <template slot-scope="scope">
                    <div :class="{'wite':scope.row.FSTATUS=='待收货'}">{{scope.row.FSTATUS}}</div>
                  </template>
                </af-table-column>
                <af-table-column
                  prop="FMODEL"
                  label="规格型号">
                </af-table-column>
                <af-table-column
                  prop="FUNIT"
                  label="单位">
                </af-table-column>
                <af-table-column
                  prop="FMANO"
                  label="物料编码">
                </af-table-column>
                <af-table-column
                  prop="FCONTRACTNO"
                  label="合同号">
                </af-table-column>
                <af-table-column
                  prop="FSUPPLIER"
                  label="供应商">
                </af-table-column>
                <el-table-column
                  align="center"
                  fixed="right"
                  label="操作"
                  width="120">
                  <template slot-scope="scope">
                    <el-button v-if="scope.row.FISCHECK=='是'" @click="handleClick(scope.row)" type="primary" size="medium" :disabled="scope.row.FRECEIVEQTY >= scope.row.FDELIVERYQTY">收货送检</el-button>
<!--                    <el-button @click="handleClick2(scope.row)" type="text" size="medium">送检</el-button>-->
                    <el-button v-if="scope.row.FISCHECK=='否'"  @click="handleClick3(scope.row)" type="success" size="medium" :disabled="scope.row.FSTATUS == '已入库'">直接入库</el-button>
                  </template>
                </el-table-column>
              </el-table>

              <button @click="qrcode" class="sao" v-if="!isShow"></button>
            </div>
          </div>
        </div>
      </div>
    <!--退出登录弹窗开始-->
      <el-dialog
              title="提示"
              :visible.sync="dialogVisible"
              :close-on-click-modal="false"
              width="40%"
              >
              <span>是否退出登录</span>
              <span slot="footer" class="dialog-footer">
          <el-button @click="dialogVisible = false">取 消</el-button>
          <el-button type="primary" @click="LogOut">确 定</el-button>
        </span>
      </el-dialog>
      <!--退出登录弹窗结束-->

      <!--收货送检弹窗开始-->
      <el-dialog title="收货送检" :close-on-click-modal="false" :visible.sync="dialogNum" width="90%">
        <el-table
          :data="receivedRow"
          border
          style="width: 100%">
          <el-table-column
            prop="FMANAME"
            label="物料名称">
          </el-table-column>
          <el-table-column
            prop="FMODEL"
            label="规格型号">
          </el-table-column>
          <el-table-column
            prop="FUNIT"
            label="单位">
          </el-table-column>
          <el-table-column
            prop="FDELIVERYQTY"
            label="送货数">
          </el-table-column>
        </el-table>
        <div style="width: 100%;height: 20px;"></div>
          <el-form :model="rulereceiveNum" :rules="rules" ref="rulereceiveNum" >
            <el-form-item prop="receiveNum" label="收货数量" >
              <el-input  v-model="rulereceiveNum.receiveNum" placeholder="请输入收货数量"   style="width: 100%;"></el-input>
            </el-form-item>

          </el-form>


        <div slot="footer" class="dialog-footer">
          <el-button @click="resetNum" size="medium">重 置</el-button>
          <el-button type="primary" @click="commits('rulereceiveNum')" size="medium" :disabled="isDisable">确 定</el-button>
          <!--<el-button type="primary" @click="subNum" size="medium" :disabled="isDisable">确 定</el-button>-->
        </div>
      </el-dialog>
      <!--收货送检弹窗结束-->

      <!--送检数量弹窗开始-->
<!--      <el-dialog title="合格数量" :close-on-click-modal="false" :visible.sync="dialogCheck" width="90%" >-->
<!--        <el-form :model="ruleCheckNum" :rules="rules" ref="ruleCheckNum">-->
<!--          <el-form-item prop="checkNum">-->
<!--            <el-input v-model="ruleCheckNum.checkNum" placeholder="请输入合格数量"   style="width: 100%;"></el-input>-->
<!--          </el-form-item>-->
<!--        </el-form>-->


<!--        <div slot="footer" class="dialog-footer">-->
<!--          <el-button @click="resetCheckNum" size="medium">重 置</el-button>-->
<!--          <el-button type="primary" @click="commitCheck('ruleCheckNum')" size="medium" :disabled="isDisable">确 定</el-button>-->
<!--        </div>-->
<!--      </el-dialog>-->
      <!--送检数量弹窗结束-->

<!--      选仓库弹窗开始-->
            <el-dialog title="选库位" :close-on-click-modal="false" :visible.sync="selectStore" width="90%" >
              <el-form :model="ruleStock" :rules="rules" ref="ruleStock">

                  <el-form-item label="选仓库:">
                    <el-select prop="checkStock" v-model="ruleStock.FStock" clearable placeholder="请选择" @change="typeSelect">
                      <el-option
                        v-for="(item,index) in Stock"
                        :key=index
                        :label="item.FNAME"
                        :value="index">
                      </el-option>
                    </el-select>
                  </el-form-item>
              </el-form>


              <div slot="footer" class="dialog-footer">
                <el-button @click="resetruleStock" size="medium">重 置</el-button>
                <el-button type="primary" @click="commitStock('ruleStock')" size="medium" :disabled="isDisable">确 定</el-button>
              </div>
            </el-dialog>
<!--      选仓库弹窗结束-->





      <!--入库数量弹窗开始-->
      <el-dialog title="直接入库" :close-on-click-modal="false" :visible.sync="dialogStore" width="90%" >
        <el-table
          :data="storeRow"
          border
          style="width: 100%">
          <el-table-column
            prop="FMANAME"
            label="物料名称">
          </el-table-column>
          <el-table-column
            prop="FMODEL"
            label="规格型号">
          </el-table-column>
          <el-table-column
            prop="FUNIT"
            label="单位">
          </el-table-column>
          <el-table-column
            prop="FDELIVERYQTY"
            label="送货数">
          </el-table-column>
        </el-table>
        <div style="width: 100%;height: 20px;"></div>


        <el-form :model="ruleStoreNum" :rules="rules" ref="ruleStoreNum">
          <el-form-item prop="storeNum" label="合格数量" class="store">
            <el-input v-model="ruleStoreNum.storeNum" placeholder="请输入合格数量"   style="width: 100%;"></el-input>
          </el-form-item>
        </el-form>


        <div slot="footer" class="dialog-footer">
          <el-button @click="resetStoreNum" size="medium">重 置</el-button>
          <el-button type="primary" @click="commit('ruleStoreNum')" size="medium" :disabled="isDisable">确 定</el-button>
        </div>
      </el-dialog>
      <!--入库数量弹窗结束-->
    </div>
</template>

<script>

    export default {
        name: "Received",
      data(){
          return{
            loading: true,
            activeIndex:'',
            isOpen:true,
            isCollapse: true,//控制侧边拦展开收起
            dialogNum:false,//收货弹窗控制
            dialogStore:false,//入库弹窗控制
            dialogCheck:false,//送检弹窗控制
            selectStore:false,//选仓库弹窗开始

            dialogVisible: false,
            isShow:false,
            isDisable:false,//控制收货多次提交数据
            saoResult:'',//扫码结果
            ruleStock:{
              FStock:''
            },
            rulereceiveNum:{
              receiveNum:'',//收货数量
            },
            ruleStoreNum:{
              storeNum:'',//合格数量
            },
            ruleCheckNum:{
              checkNum:''//送检数量
            },

            rules:{
              receiveNum:[
                {required: true, message: '请输入收货数量', trigger: 'blur'},
                // { type: 'number', message: '格式不正确'}
              ],
              storeNum:[
                {required: true, message: '请输入合格数量', trigger: 'blur'},
                // { type: 'number', message: '格式不正确'}
              ],
              checkNum:[
                {required: true, message: '请输入合格数量', trigger: 'blur'},
                // { type: 'number', message: '格式不正确'}
              ],
              checkStock:[
                {required: true, message: '请选择仓库', trigger: 'blur'},
              ]
            },
            tableData: [],
            receivedRow:[],
            storeRow:[],
            checkRow:[],
            numData:[],//收货组装数据
            checkData:[],//送检组装数据
            StoreData:[],//入库组装数据
            multipleSelection: [],
            Stock:[],
            selectStock:[]

          }
      },
      mounted() {
       this.activeIndex = ''

      },
      watch:{
          $route(){
            this.jihuo(this.activeIndex)
          }
      },
      created(){
        window.aa = this.aa;
        window.bb = this.bb;

      },
      methods:{
          //选仓库
        pisock(){

          if(this.multipleSelection.length>0){
            this.selectStore = true
            this.selectStock = this.multipleSelection
            this.getStock()

          }else{
            this.$message.warning('请勾选需要选库位的物料');
          }
        },
        //请求仓库数据
        getStock(){
          this.$axios.get(this.GLOBAL.baseURL + '/stock').then((response) => {
            //console.log(response.data)
            this.Stock = response.data
            console.log(this.Stock)
          }).catch((err) => {
            console.log(err)

          })
        },
          //批量送检
        piCheck(){
          //console.log(this.multipleSelection)
          //如果选择有要直接入库的则提示，去掉直接入库
           //this.numData= []
          if(this.multipleSelection.length>0){
            this.numData=[]
            for (var i =0;i<this.multipleSelection.length;i++){
              if(this.multipleSelection[i].FISCHECK == '否'){
                this.$message.warning('请去掉直接入库的物料后在提交');
                this.$refs.multipleTable.clearSelection();
                return;
              }
              this.numData.push({
                            fuser: this.GLOBAL.userData.UserName,
                            fid: this.multipleSelection[i].FID,
                            fentryid: this.multipleSelection[i].FENTRYID,
                            fqty: this.multipleSelection[i].FDELIVERYQTY
                          })
                }
            //批量送检数据提交
            this.$axios.post(this.GLOBAL.baseURL + '/purReceival',this.numData).then((response) => {
              // console.log(response.data)
              if(response.data.success == true){
                //收货成功,刷新收货清单数据
                this.dialogNum = false
                this.$message.success('收货成功');
                this.GetReceived(this.saoResult)


              }else {
                this.$message.error(response.data.result);
              }

            }).catch((err) => {
              console.log(err)
            })
            this.isDisable = false
            this.$refs.multipleTable.clearSelection();

          }else{
            this.$message.warning('请勾选需要送检的物料');
          }



          console.log(this.numData)

          //this.$refs.multipleTable.clearSelection();
        },
        handleSelectionChange(val) {
          this.multipleSelection = val;
          //console.log(this.multipleSelection)
        },
        qie(){

         this.isOpen = !this.isOpen
          this.GLOBAL.isState = !this.GLOBAL.isState
          // this.tests()


        },
        jihuo(index){
          this.activeIndex = index

        },
        tests(){
          if(this.isShow = false){
            this.isShow = true
          }
        },
        //收货送检
        handleClick(row) {
          this.dialogNum = true
          this.receivedRow = []
          this.receivedRow.push({
            FMANAME:row.FMANAME,
            FMODEL:row.FMODEL,
            FUNIT:row.FUNIT,
            FDELIVERYQTY:row.FDELIVERYQTY,//送货数量
            FID:row.FID,
            FENTRYID:row.FENTRYID,
            FRECEIVEQTY:row.FRECEIVEQTY//收货数量
          })
          this.rulereceiveNum.receiveNum = row.FDELIVERYQTY
          //console.log(this.receivedRow)

        },
        //入库
        handleClick3(row) {
          this.dialogStore = true
          this.storeRow = []
          this.storeRow.push({
            FMANAME:row.FMANAME,
            FMODEL:row.FMODEL,
            FUNIT:row.FUNIT,
            FDELIVERYQTY:row.FDELIVERYQTY,//送货数量
            FID:row.FID,
            FENTRYID:row.FENTRYID,
            FRECEIVEQTY:row.FRECEIVEQTY//收货数量
          })
          this.ruleStoreNum.storeNum=row.FDELIVERYQTY


        },
        //送检
        handleClick2(row) {
          this.dialogCheck = true
          this.checkRow = row
          this.ruleCheckNum.checkNum = ''
        },
        //收货送检提交
        commits(formName){
          this.$refs[formName].validate((valid) => {
            // alert(valid)
            if (valid) {
              if (this.rulereceiveNum.receiveNum > (this.receivedRow[0].FDELIVERYQTY - this.receivedRow[0].FRECEIVEQTY)) {
                this.$message.error('可填报收货数量最大为' + (this.receivedRow[0].FDELIVERYQTY - this.receivedRow[0].FRECEIVEQTY));

              } else {
                this.isDisable = true
                this.dialogNum = false
                this.subNum();
              }

            } else {
              console.log('error submit!!');
              return false;
            }
          });
        },
        //入库提交
        commit(formName){
          this.$refs[formName].validate((valid) => {
            // alert(valid)
            if (valid) {
              if (this.ruleStoreNum.storeNum > this.storeRow[0].FDELIVERYQTY) {
                this.$message.error('可填报合格数量最大为' + this.storeRow[0].FDELIVERYQTY);

              } else {
                this.isDisable = true
                this.dialogStore = false

                this.subStoreNum();
              }

            } else {
              console.log('error submit!!');
              return false;
            }
          });
        },
        //选仓库提交
        commitStock(formName){
          this.$refs[formName].validate((valid) => {
            // alert(valid)
            if (valid) {
              alert("ss")

            } else {
              console.log('error submit!!');
              return false;
            }
          });
        },
        //送检提交
        commitCheck(formName){
          this.$refs[formName].validate((valid) => {
            // alert(valid)
            if (valid) {
              if (this.ruleCheckNum.checkNum > this.checkRow.FRECEIVEQTY) {
                this.$message.error('可填报合格数量最大为' + this.checkRow.FRECEIVEQTY);

              } else {
                this.isDisable = true
                this.dialogCheck = false

                 this.subCheckNum();
              }

            } else {
              console.log('error submit!!');
              return false;
            }
          });
        },
        //送检请求数据
        subCheckNum(){
          this.checkData=[]
          this.checkData.push({
            fuser: this.GLOBAL.userData.UserName,
            fid: this.checkRow.FID,
            fentryid: this.checkRow.FENTRYID,
            fqty:this.ruleCheckNum.checkNum,


          })
          //console.log(this.checkData)
           this.$axios.post(this.GLOBAL.baseURL + '/QCBill', this.checkData).then((response) => {
             console.log(response.data)
             if(response.data.success == true){
               //送检成功,刷新收货清单数据
               console.log(response.data)
               this.$message.success('操作成功');
               this.GetReceived(this.saoResult)


             }else {
               this.$message.error(response.data.result);
             }

           }).catch((err) => {
             console.log(err)
           })

        },


        subStoreNum(){
          this.StoreData=[]
          this.StoreData.push({
            fuser: this.GLOBAL.userData.UserName,
            fid: this.storeRow[0].FID,
            fentryid: this.storeRow[0].FENTRYID,
            fqty: this.ruleStoreNum.storeNum
          })

          this.$axios.post(this.GLOBAL.baseURL + '/DPurInWare',this.StoreData,{
            headers:{"Authorization":"Bearer" + " " + this.GLOBAL.token}
          }).then((response) => {
            console.log(response.data)
            if(response.data.success == true){
              //入库成功,刷新收货清单数据
              this.dialogStore = false
              this.$message.success("入库成功");
              this.GetReceived(this.saoResult)


            }else {
              this.$message.error(response.data.result);

            }

          }).catch((err) => {
            console.log(err)
          })
          this.isDisable = false
        },
        subNum(){
          this.numData=[]
          // console.log("this.numData")
          //console.log(this.numData)
            this.numData.push({
              fuser: this.GLOBAL.userData.UserName,
              fid: this.receivedRow[0].FID,
              fentryid: this.receivedRow[0].FENTRYID,
              fqty: this.rulereceiveNum.receiveNum,
              fstockid:'',
              flocationid:''
            })

              this.$axios.post(this.GLOBAL.baseURL + '/purReceival',this.numData).then((response) => {
                // console.log(response.data)
                if(response.data.success == true){
                  //收货成功,刷新收货清单数据
                  this.dialogNum = false
                  this.$message.success('收货成功');
                  this.GetReceived(this.saoResult)


                }else {
                  this.$message.error(response.data.result);

                }

              }).catch((err) => {
                console.log(err)
              })

          this.isDisable = false
        },
        resetNum(){
          this.rulereceiveNum.receiveNum = ''
        },
        resetStoreNum(){
          this.ruleStoreNum.storeNum = ''
        },
        resetCheckNum(){
          this.ruleCheckNum.checkNum = ''
        },
        resetruleStock(){
          this.ruleStock.FStock = ''
        },
        handleCommand(command){

          if(command == 'loginout'){
            this.dialogVisible = true
            this.$refs.dropdown.hide()
          }
        },
        //退出登录并清空用户数据
        LogOut(){

          // this.GLOBAL.userData={}
          // localStorage.clear()
          // this.GLOBAL.token = ''
          // this.dialogVisible = false;
          AndroidJs.exit();
          // this.$router.push('/login')

          // BSL.SetJsClose()


          //退出登录后禁止浏览器后退
          // history.pushState(null,null,document.URL);
          // window.addEventListener("popstate",function (e) {
          //   history.pushState(null,null,document.URL)
          // },false)

        },
        //请求收货清单
        GetReceived(date){
          this.isShow = true
          this.$axios.get(this.GLOBAL.baseURL + '/deliveryBill/'+date).then((response) => {
            console.log(response.data)
            this.tableData = response.data
            this.loading = false
          }).catch((err) => {
            console.log(err)
            this.loading = false
          })
        },
        aa(result) {

          this.saoResult = result
          this.GetReceived(this.saoResult)


        },
        qrcode(){
          //网页调试
          this.GetReceived('FH_000073844')

          // BSL.Qcode('0','aa')
          AndroidJs.scan('aa');

        },

      }
    }
</script>

<style scoped>
  .el-button--medium{padding: 10px 10px;}
  .received{height: 100%;}
  .sao{background: url("../../assets/imgs/sao.png") no-repeat;border: none;width: 165px;height: 165px;margin-left: 50%;transform: translateX(-50%);margin-top: 200px;}
  .wite{color: red;}
  .el-form-item__label{color: #180e0c !important;}
  .pi-button{float: right;margin-right: 20px;margin-top: 5px;}

</style>
